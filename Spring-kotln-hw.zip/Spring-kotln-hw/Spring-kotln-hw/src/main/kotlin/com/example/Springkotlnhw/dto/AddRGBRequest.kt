package com.example.Springkotlnhw.dto

data class AddRGBRequest(val red: Int = 0, val green: Int = 0, val blue: Int = 0) {
}