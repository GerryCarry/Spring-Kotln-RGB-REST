package com.example.Springkotlnhw.dto

data class RGBResponse(val id:Long, val red: Int = 0, val green: Int = 0, val blue: Int = 0) {
}