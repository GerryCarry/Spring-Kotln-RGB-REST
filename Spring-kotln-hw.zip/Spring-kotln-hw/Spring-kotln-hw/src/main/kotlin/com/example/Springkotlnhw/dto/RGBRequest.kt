package com.example.Springkotlnhw.dto

data class RGBRequest(val id: Long, val red: Int = 0, val green: Int = 0, val blue: Int = 0) {
}