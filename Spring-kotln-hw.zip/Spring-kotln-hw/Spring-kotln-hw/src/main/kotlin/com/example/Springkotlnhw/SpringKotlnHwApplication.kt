package com.example.Springkotlnhw

import org.springframework.boot.autoconfigure.SpringBootApplication
import org.springframework.boot.runApplication


@SpringBootApplication
class SpringKotlnHwApplication

fun main(args: Array<String>) {
	runApplication<SpringKotlnHwApplication>(*args)
}
